//Null termination method
#include<stdio.h>
#include<stdarg.h>
void fun(int c,...);
int main()
{
	fun(10,20,0);
	fun(11,22,33,0);
	fun(12,24,36,44,0);
}
void fun(int c,...)
{
	int i,ret;
	va_list ap;
	va_start(ap,c);

	printf("%d  ",c);
	while(ret = va_arg(ap,int))
	printf("%d  ",ret);

	printf("\n");
}
